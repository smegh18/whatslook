<?php
/**
 * Stripe configuration for the standalone PHP backend.
 * Prefer environment variables in production and keep this file outside the web root if possible.
 */

$publishableKey = getenv('STRIPE_PUBLISHABLE_KEY') ?: 'pk_test_51Tla1XJtar6xmk7MAppv7QEQrz86NzQUZRjOf61WJCx0OXpW04oHEy4ttAkWsxwGIQoQohTAx0GxkGYaoZ48k1WS00tSaRSCAa';
$secretKey      = getenv('STRIPE_SECRET_KEY') ?: 'sk_test_51Tla1XJtar6xmk7M1e9OfrSCbaWzhSUfouIwxiNTURcJ3o8ypL0Ab9HmoRCNKQTFnbHbh3AHlQRMkdvrwPw6z5kb00U8JeM7u9';

if (!defined('STRIPE_PUBLISHABLE_KEY')) {
    define('STRIPE_PUBLISHABLE_KEY', $publishableKey);
}
if (!defined('STRIPE_SECRET_KEY')) {
    define('STRIPE_SECRET_KEY', $secretKey);
}

// Initialize Stripe SDK
require_once __DIR__ . '/vendor/autoload.php';
\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);
?>