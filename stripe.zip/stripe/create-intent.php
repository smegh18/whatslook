<?php
header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

try {
    $rawBody = file_get_contents('php://input');
    $input = [];

    if (!empty($rawBody)) {
        $decoded = json_decode($rawBody, true);
        if (is_array($decoded)) {
            $input = $decoded;
        }
    }

    if (empty($input)) {
        $input = $_POST;
    }

    if (empty($input) && isset($_GET['amount'])) {
        $input = $_GET;
    }

    $amount = $input['amount'] ?? $input['amount_cents'] ?? null;
    $currency = strtolower($input['currency'] ?? 'usd');
    $description = $input['description'] ?? 'Coin purchase';
    $coinPackageId = $input['coin_package_id'] ?? $input['coinPackageId'] ?? null;

    if (!is_numeric($amount) || (int) $amount <= 0) {
        http_response_code(400);
        echo json_encode([
            'status' => false,
            'message' => 'Amount is required and must be a positive number in cents.'
        ]);
        exit;
    }

    $intent = \Stripe\PaymentIntent::create([
        'amount' => (int) $amount,
        'currency' => $currency,
        'description' => $description,
        'automatic_payment_methods' => ['enabled' => true],
        'metadata' => [
            'coin_package_id' => (string) $coinPackageId,
            'source' => 'standalone_php_backend'
        ],
    ]);

    http_response_code(200);
    echo json_encode([
        'status' => true,
        'paymentIntent' => $intent->client_secret,
        'paymentIntentId' => $intent->id,
        'clientSecret' => $intent->client_secret,
        'customer' => null,
        'ephemeralKey' => null,
        'id' => $intent->id,
    ]);
} catch (\Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ]);
}
?>