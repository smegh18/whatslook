<?php
// webhook.php
header('Content-Type: application/json');

require_once __DIR__ . '/config.php';

// Stripe recommends using the raw request body for verification
$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? null;
$endpoint_secret = 'whsec_XXXXXXXXXXXXXXXXXXXXXXXX'; // <-- Replace with your webhook secret from Dashboard

try {
    $event = \Stripe\Webhook::constructEvent(
        $payload,
        $sig_header,
        $endpoint_secret
    );
} catch (\UnexpectedValueException $e) {
    // Invalid payload
    http_response_code(400);
    exit();
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    // Invalid signature
    http_response_code(400);
    exit();
}

// Handle the event
switch ($event->type) {
    case 'payment_intent.succeeded':
        $paymentIntent = $event->data->object; // /* \Stripe\PaymentIntent */
        // ✅ Payment was successful – fulfill the order, send email, update DB, etc.
        error_log('✅ PaymentIntent succeeded: ' . $paymentIntent->id);
        // TODO: add your business logic here
        break;

    case 'payment_intent.payment_failed':
        $paymentIntent = $event->data->object;
        error_log('❌ PaymentIntent failed: ' . $paymentIntent->id);
        // TODO: handle failed payment (notify user, etc.)
        break;

    // Add more event types as needed (e.g., charge.refunded, invoice.payment_failed, etc.)
    default:
        // Unexpected event type
        error_log('⚠️ Received unhandled event type: ' . $event->type);
        break;
}

// Return a 200 response to acknowledge receipt of the event
http_response_code(200);
echo json_encode(['received' => true]);
?>